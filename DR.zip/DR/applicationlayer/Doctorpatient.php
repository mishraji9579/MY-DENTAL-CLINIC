<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My Dental Clinic</title>
<link href="style1.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="banner">
<span class="head"><center>MY DENTAL CLINIC</center></span><br />
<marquee class="clg" direction="right" behavior="alternate" scrollamount="5">(DESIGNED & CREATED UNDER FASTFINDFIRM)</marquee>

</div>
<br />
<div align="center">
<div id="wrapper">
<br />
<br />
<br />
<br />

<br />

<span class="SubHead">WELCOME</span>
<br />
<br />


<table >
<br />

<br />

<br />

<br />

<br />

<br />
<br />
<br />
<br />
<div class="wrapper">
		<div class="btn" > <a href="login3.php">

<button type="button" class="buttonA" > Admin</button>

</div>
<br/>
<br />
<br />

</div>


	<div class="wrapper" style="text-decoration: none;">
	<div class="btn" > <a href="login.php"  >
<button type="button" class="buttonP">Patient</button>
</div>

</div>

<br />
<br />
</table>

</div>
</div>
</body>
</html>